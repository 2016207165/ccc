package com.util;

public class Page {

	/**
	 * 获得各类数据库的分页查询语句 sql 查询语句 select * from ly , curPage第几页, pagesize 一页显示几条,
	 * indexKey 排序关键字 id , sort 排序 asc/desc , type 数据库类型 mysql,mssql,oracle,db2
	 */
	public static String getSql(String sql, long curPage, int pageSize,
			String indexKey, String sort, String types) {
		String create_sql = "";
		if (types.toUpperCase().trim().equals("MYSQL")) // mysql
		{
			create_sql = sql + " order by " + indexKey.trim() + " "
					+ sort.trim() + " limit " + ((curPage - 1) * pageSize)
					+ "," + pageSize;
		} else if (types.toUpperCase().trim().equals("MSSQL")) // ms sql
		{
			if (curPage == 1) {
				create_sql = "select top " + pageSize + " * from (" + sql
						+ ") as t1 order by  " + indexKey.trim() + " " + sort
						+ " ";
			} else {
				String min_max = "";
				if (sort.toUpperCase().trim().equals("ASC")) {
					min_max = " >(select max";
				} else if (sort.toUpperCase().trim().equals("DESC")) {
					min_max = " <(select min";
				} else {
					min_max = " >(select max";
				}
				create_sql = "select top " + pageSize + " * from (" + sql
						+ ") as t1 " + " where (t1." + indexKey.trim()
						+ min_max + "(t3." + indexKey.trim() + ")"
						+ " from (select top " + (curPage - 1) * pageSize
						+ " t2." + indexKey.trim() + " from (" + sql
						+ ") as t2 order by t2." + indexKey.trim() + " " + sort
						+ " " + " ) as t3" + " )) order by t1."
						+ indexKey.trim() + " " + sort + " ";
			}
		} else if (types.toUpperCase().trim().equals("ORACLE")) // oracle
		{
			String str_sql = sql + " order by " + indexKey.trim() + " "
					+ sort.trim() + " ";
			create_sql = "select * from (select mytable.*,rownum as my_rownum from ("
					+ str_sql
					+ ") mytable where my_rownum<="
					+ (curPage * pageSize)
					+ ") where my_rownum>"
					+ ((curPage - 1) * pageSize);

		} else if (types.toUpperCase().trim().equals("DB2")) // db2
		{
			StringBuilder c = new StringBuilder();
			c.append("select * from (");
			c.append(sql);
			c.append(") as w");
			c.append(" where ROW_NO between ");
			c.append(((curPage - 1) * pageSize));
			c.append(" and ");
			c.append((curPage * pageSize));
			create_sql = c.toString();
		} else // 默认为mysql
		{
			create_sql = sql + " order by " + indexKey.trim() + " "
					+ sort.trim() + " limit " + (curPage - 1) * pageSize + 1
					+ "," + pageSize;
		}
		return create_sql;
	}

	/**
	 * 获得分页字符串 size 数据总长度 pageSize 一页条数 curpage 当前页数 target 跳转链接（action find）
	 */
	public static String getPagestr(int size, int pageSize, long curPage,
			String target) {
		String linkStr = "";
		int pages = 0;// 总页数
		// 计算总页数
		// int size = list_from_dao.size();
		float temp = (float) size / (float) pageSize;
		int temp2 = size / pageSize; // 总页数

		if (temp2 == 0) {
			pages = 1;
		} else if (temp > temp2) {
			pages = temp2 + 1;
		} else {
			pages = temp2;
		}

		linkStr = "<form name='pageform' method='post' > <B><font color=red size=3>共"
				+ size
				+ "条 共"
				+ pages
				+ "页 每页"
				+ pageSize
				+ "条 第"
				+ curPage
				+ "页</font></B>";
		// " 去第 <select onchange=gotopage(this) id=curPage name=curPage>";
		// for (int i = 1; i <= pages; i++) {
		// if (i == curPage) {
		// linkStr = linkStr + "<option value=" + i + " selected>" + i
		// + "</option>";
		// } else {
		// linkStr = linkStr + "<option value=" + i + ">" + i
		// + "</option>";
		// }
		// }
		// linkStr = linkStr + "</select> 页 ";

		if (pages == 1)
			linkStr = linkStr + "[<font color=red size=3>首页</font>/";
		else if (curPage == 1)// 如果当前页就是第一页
		{
			linkStr = linkStr + "[<font color=red size=3>首页</font>/";
		} else
			linkStr = linkStr + "[<A title=转至首页 href=" + target
					+ "curPage=1><font color=blue size=3>首页</font></a>/";
		if (curPage == pages)
			linkStr = linkStr + "<font color=red size=3>末页</font>] ";
		else if (pages == 1)// 页数就是一页
		{
			linkStr = linkStr + "<font color=red size=3>末页</font>] ";
		} else
			linkStr = linkStr + "<A title=转至末页 href=" + target + "curPage="
					+ pages + "><font color=blue size=3>末页</font></A>] ";
		linkStr = linkStr + "[";
		if (curPage == 1)// 当前页是第一页
		{
			linkStr = linkStr + "<font color=red size=3>上页</font>/";
		} else {
			long l1 = curPage - 1;
			linkStr = linkStr + "<a title=转至上页 href=" + target + "curPage="
					+ l1 + "><font color=blue size=3>上页</font></a>/";
		}
		if (curPage < pages) {
			long i2 = curPage + 1;
			linkStr = linkStr + "<A title=转至下页 href=" + target + "curPage="
					+ i2 + "><font color=blue size=3>下页</font></A>]";
		} else {
			linkStr = linkStr + "<font color=red size=3>下页</font>]";
		}
		linkStr = linkStr
				+ "<input type='text' length=5 id='page' name='page' onkeypress='kpNum()' onpaste='return false' style='ime-mode:disabled'/>"
				+ "<input type='hidden' name='maxpage' id='maxpage'"
				+ " value='"
				+ pages
				+ "'/><input type='button'  value='go' onClick='gotopage()'\n </form>";
		String go = "\n<script type=\"text/javascript\">\n function gotopage(){\n"
				+ "var page = document.getElementById('page').value;\n "
				+ "var maxpage = document.getElementById('maxpage').value;\n "
				+ "if(parseInt(maxpage)<parseInt(page)) \n page=maxpage; \n "
				+ "document.pageform.action='"
				+ target
				+ "curPage='+page;document.pageform.submit();\n }\n "
				+ "function kpNum(){\n  if(window.event.keyCode<48 || window.event.keyCode>57)  \n window.event.returnValue=false;\n }"
				+ "</script>";
		// <input type="text" size=3 name="gopage"
		// onkeydown="if(event.keyCode==13) {return false;}"> <input
		// type="button" value="go"
		// onClick="javascript:gotopage(0,'AddGdChaXunInfoList','AddGdChaXunCmd','true');">
		// document.pageform.action='"
		// +target+"curPage='+document.page.value;document.pageform.submit()
		// String go="<form name='pageform' method='post'></form><script
		// type=\"text/javascript\">function gotopage(page){
		// alert(page.value)}</script>";
		linkStr = linkStr + go;
		return linkStr;

	}

	// $$$$$$$$$$$$$$$$$$$$$$$以下勿删
	// public static String getPagestr(int size, int pageSize, long curPage,
	// String target) {
	// String linkStr = "";
	// int pages = 0;// 总页数
	// // 计算总页数
	// // int size = list_from_dao.size();
	// float temp = (float) size / (float) pageSize;
	// int temp2 = size / pageSize; // 总页数
	//
	// if (temp2 == 0) {
	// pages = 1;
	// } else if (temp > temp2) {
	// pages = temp2 + 1;
	// } else {
	// pages = temp2;
	// }
	//
	// linkStr = "<B><font color=#FF0000>共"
	// + size
	// + "条 共"
	// + pages
	// + "页 每页"
	// + pageSize
	// + "条 第"
	// + curPage
	// + "页</font></B> 去第 <select onchange=gotopage(this) id=curPage
	// name=curPage>";
	// for (int i = 1; i <= pages; i++) {
	// if (i == curPage) {
	// linkStr = linkStr + "<option value=" + i + " selected>" + i
	// + "</option>";
	// } else {
	// linkStr = linkStr + "<option value=" + i + ">" + i
	// + "</option>";
	// }
	// }
	// linkStr = linkStr + "</select> 页 ";
	//
	// if (pages == 1)
	// linkStr = linkStr + "[<font color=red>首页</font>/";
	// else if (curPage == 1)// 如果当前页就是第一页
	// {
	// linkStr = linkStr + "[<font color=red>首页</font>/";
	// } else
	// linkStr = linkStr + "[<A title=转至首页 href=" + target
	// + "curPage=1><font color=blue>首页</font></a>/";
	// if (curPage == pages)
	// linkStr = linkStr + "<font color=red>末页</font>] ";
	// else if (pages == 1)// 页数就是一页
	// {
	// linkStr = linkStr + "<font color=red>末页</font>] ";
	// } else
	// linkStr = linkStr + "<A title=转至末页 href=" + target + "curPage="
	// + pages + "><font color=blue>末页</font></A>] ";
	// linkStr = linkStr + "[";
	// if (curPage == 1)// 当前页是第一页
	// {
	// linkStr = linkStr + "<font color=red>上页</font>/";
	// } else {
	// long l1 = curPage - 1;
	// linkStr = linkStr + "<a title=转至上页 href=" + target + "curPage="
	// + l1 + "><font color=blue>上页</font></a>/";
	// }
	// if (curPage < pages) {
	// long i2 = curPage + 1;
	// linkStr = linkStr + "<A title=转至下页 href=" + target + "curPage="
	// + i2 + "><font color=blue>下页</font></A>]";
	// } else {
	// linkStr = linkStr + "<font color=red>下页</font>]";
	// }
	// String go="<form name='pageform' method='post'></form><script
	// type=\"text/javascript\">function gotopage(page){
	// document.pageform.action='"
	// +target+"curPage='+page.value;document.pageform.submit()}</script>";
	// // String go="<form name='pageform' method='post'></form><script
	// type=\"text/javascript\">function gotopage(page){
	// alert(page.value)}</script>";
	// linkStr=linkStr+go;
	// return linkStr;
	//
	// }

	/**
	 * 获得分页字符串 size 数据总长度 pageSize 一页条数 curpage 当前页数 target 跳转链接（action find）
	 */
	public static String getstr(int size, int pageSize, long curPage,
			String target) {
		String linkStr = "";
		int pages = 0;// 总页数
		// 计算总页数
		// int size = list_from_dao.size();
		float temp = (float) size / (float) pageSize;
		int temp2 = size / pageSize; // 总页数

		if (temp2 == 0) {
			pages = 1;
		} else if (temp > temp2) {
			pages = temp2 + 1;
		} else {
			pages = temp2;
		}
		// 首页
		if (pages == 1)
			linkStr = linkStr + "<font color=red>|<- </font>";
		else if (curPage == 1)// 如果当前页就是第一页
		{
			linkStr = linkStr + "<font color=red>|<- </font>";
		} else
			linkStr = linkStr + "<A title=转至首页 href=" + target
					+ "curPage=1><font color=blue>|<- </font></a>";
		// 上一页
		if (curPage == 1)// 当前页是第一页
		{
			linkStr = linkStr + "<font color=red><- </font>";
		} else {
			long l1 = curPage - 1;
			linkStr = linkStr + "<a title=转至上页 href=" + target + "curPage="
					+ l1 + "><font color=blue><- </font></a>";
		}
		// 下一页
		if (curPage < pages) {
			long i2 = curPage + 1;
			linkStr = linkStr + "<A title=转至下页 href=" + target + "curPage="
					+ i2 + "><font color=blue> -></font></A>";
		} else {
			linkStr = linkStr + "<font color=red> -></font>";
		}
		// 末页
		if (curPage == pages)
			linkStr = linkStr + "<font color=red> ->|</font> ";
		else if (pages == 1)// 页数就是一页
		{
			linkStr = linkStr + "<font color=red> ->|</font> ";
		} else
			linkStr = linkStr + "<A title=转至末页 href=" + target + "curPage="
					+ pages + "><font color=blue> ->|</font></A> ";
		linkStr = linkStr + "";

		return linkStr;

	}

}
